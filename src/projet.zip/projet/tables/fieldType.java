package projet.tables;

public enum fieldType {
	NUMERIC, VARCHAR, FLOAT8, INT4;
}
